import React from "react";

export default function NotFoundPage() {
  return <h1>404: Page Not Found!</h1>;
}
